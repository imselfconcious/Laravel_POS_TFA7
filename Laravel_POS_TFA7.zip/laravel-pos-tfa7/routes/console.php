<?php
// Application console routes.
